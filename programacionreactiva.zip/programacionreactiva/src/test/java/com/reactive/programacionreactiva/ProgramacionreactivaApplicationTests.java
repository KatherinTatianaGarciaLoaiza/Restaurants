package com.reactive.programacionreactiva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgramacionreactivaApplicationTests {

	@Test
	void contextLoads() {
	}

}
