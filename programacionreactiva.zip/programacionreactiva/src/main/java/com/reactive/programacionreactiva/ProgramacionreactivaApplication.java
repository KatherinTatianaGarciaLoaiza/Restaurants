package com.reactive.programacionreactiva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgramacionreactivaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgramacionreactivaApplication.class, args);
	}

}
